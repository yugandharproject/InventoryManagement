spool C:\REPL\ims_jpr\spool\mas1b.lst;

ALTER TABLE AO_MOVEMENT_DETAIL DROP  CONSTRAINT FK_FROM_TO_WH;

/

spool off;